package com.Admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddPatientServlet")
public class AddPatientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int patient_id = Integer.parseInt(request.getParameter("patient_id"));
        String disease_description = request.getParameter("disease_description");
        int age = Integer.parseInt(request.getParameter("age"));
        String contact_no = request.getParameter("contact_no");
        String fee_paid = request.getParameter("fee_paid");
        String consult_doctor = request.getParameter("consult_doctor");
        String prescription = request.getParameter("prescription");
        String visit_date = request.getParameter("visit_date");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb", "root", "root");
            PreparedStatement ps = con.prepareStatement(
            	    "INSERT INTO addpatient (patient_id, disease_description, age, contact_no, fee_paid, consult_doctor, prescription, visit_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            	);
            	ps.setInt(1, patient_id);
            	ps.setString(2, disease_description);
            	ps.setInt(3, age);
            	ps.setString(4, contact_no);
            	ps.setString(5, fee_paid);
            	ps.setString(6, consult_doctor);
            	ps.setString(7, prescription);
            	ps.setString(8, visit_date);
            	ps.executeUpdate();
            response.sendRedirect("admin.jsp?msg=Patient Added Successfully");
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}