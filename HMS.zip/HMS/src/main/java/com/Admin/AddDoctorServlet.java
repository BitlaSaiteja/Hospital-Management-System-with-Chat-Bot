package com.Admin;
import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
@WebServlet("/AddDoctorServlet")
public class AddDoctorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");
        String qualification = request.getParameter("qualification");
        String experience = request.getParameter("experience");
        String hospital = request.getParameter("hospital");
        String address = request.getParameter("address");
        String speciality = request.getParameter("speciality");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb", "root", "root");

            String query = "INSERT INTO adddoctor VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, email);
            ps.setString(4, contact);
            ps.setString(5, qualification);
            ps.setString(6, experience);
            ps.setString(7, hospital);
            ps.setString(8, address);
            ps.setString(9, speciality);

            int i = ps.executeUpdate();
            if (i > 0) {
                response.sendRedirect("admin.jsp");
            } else {
                response.sendRedirect("addDoctor.jsp?error=Failed to add doctor");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}