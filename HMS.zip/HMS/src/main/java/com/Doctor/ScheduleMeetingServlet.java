package com.Doctor;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/ScheduleMeetingServlet")
public class ScheduleMeetingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String meetingDate = request.getParameter("meeting_date");
        String availableSlots = request.getParameter("available_slots");
        String doctorUsername = (String) request.getSession().getAttribute("doctor_username");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb", "root", "root");
            PreparedStatement ps = con.prepareStatement("INSERT INTO meetings (username, meeting_date, available_slots) VALUES (?, ?, ?)");
            ps.setString(1, doctorUsername);
            ps.setString(2, meetingDate);
            ps.setString(3, availableSlots);
            ps.executeUpdate();
            con.close();
            response.sendRedirect("doctor_dashboard.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
