package com.Doctor;

import jakarta.servlet.ServletException;
import java.sql.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/UpdateTimetableServlet")
public class UpdateTimetableServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newTimetable = request.getParameter("new_timetable");
        String availableSlots = request.getParameter("available_slots");
        String doctorUsername = (String) request.getSession().getAttribute("doctor_username");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb", "root", "root");
            PreparedStatement ps = con.prepareStatement("UPDATE timetable1 SET time_table=?, available_slots=? WHERE username=?");
            ps.setString(1, newTimetable);
            ps.setString(2, availableSlots);
            ps.setString(3, doctorUsername);
            ps.executeUpdate();
            con.close();
            response.sendRedirect("doctor_dashboard.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}