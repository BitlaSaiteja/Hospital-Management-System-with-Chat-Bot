package com.Patient;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/PatientLoginServlet")
public class PatientLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String patientId = request.getParameter("patient_id");

        try {
            // Database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitaldb", "root", "root");

            // Check if patient ID exists
            String query = "SELECT * FROM addpatient WHERE patient_id=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, patientId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                // Create session and redirect to dashboard
                HttpSession session = request.getSession();
                session.setAttribute("patient_id", patientId);
                response.sendRedirect("patient_dashboard.jsp");
            } else {
                // Redirect to login with error
                response.sendRedirect("patient_login.jsp?error=Invalid Patient ID");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("patient_login.jsp?error=Database Error");
        }
    }
}

