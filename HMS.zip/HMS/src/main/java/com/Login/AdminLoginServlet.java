package com.Login;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.http.*;
@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
         
        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/hospitaldb"; // Change as per your DB
        String dbUser = "root"; // Change your DB user
        String dbPassword = "root"; // Change your DB password

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Query to check admin credentials
            String sql = "SELECT * FROM admin WHERE user = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("adminUser", username);
                response.sendRedirect("admin.jsp"); // Redirect to admin dashboard
            } else {
                request.setAttribute("errorMessage", "Incorrect username or password. Try again.");
                request.getRequestDispatcher("admin_login.jsp").forward(request, response);
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.print("<h1>"+e+"</h1>");
        }
    }
}
