package com.ChatBot;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;

@WebServlet("/ChatbotServlet")
public class ChatbotServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String query = request.getParameter("query").trim().toLowerCase();
        response.setContentType("text/html;charset=UTF-8");

        // Handle greetings separately
        if (query.equals("hi") || query.equals("hello") || query.equals("hey")) {
            response.getWriter().write("Hello! How can I assist you?<br>");
            return;
        }

        String doctorName = "No doctor found";
        String email = "N/A";
        String contact = "N/A";
        String qualification = "N/A";
        String experience = "N/A";
        String hospital = "N/A";
        String address = "N/A";
        int maxMatchScore = 0;

        try {
            // Database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HospitalDB", "root", "root");

            // Fetch all doctors and their specialties
            String queryDoctor = "SELECT * FROM adddoctor";
            PreparedStatement pst = con.prepareStatement(queryDoctor);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String speciality = rs.getString("speciality").toLowerCase();
                List<String> specialityWords = Arrays.asList(speciality.split(" "));
                List<String> queryWords = Arrays.asList(query.split(" "));

                // Calculate match score based on the number of words matching
                int matchScore = 0;
                for (String qWord : queryWords) {
                    if (specialityWords.contains(qWord)) {
                        matchScore++;
                    }
                }

                // Update doctor details if this specialty has the highest match score
                if (matchScore > maxMatchScore) {
                    maxMatchScore = matchScore;
                    doctorName = rs.getString("username");
                    email = rs.getString("emailid");
                    contact = rs.getString("contact_no");
                    qualification = rs.getString("qualification");
                    experience = rs.getString("experience_details");
                    hospital = rs.getString("hospital_name");
                    address = rs.getString("address");
                }
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error processing request.<br>");
            return;
        }

        // Forming chatbot response
        String botResponse = "👨‍⚕️ <b>Doctor:</b> " + doctorName +
                             "<br>📧 <b>Email:</b> " + email +
                             "<br>📞 <b>Contact:</b> " + contact +
                             "<br>🎓 <b>Qualification:</b> " + qualification +
                             "<br>🏥 <b>Experience:</b> " + experience +
                             "<br>🏨 <b>Hospital:</b> " + hospital +
                             "<br>📍 <b>Address:</b> " + address + "<br>";

        response.getWriter().write(botResponse);
    }
}
